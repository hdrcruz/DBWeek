import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.conf.Configured;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.util.Tool;
import org.apache.hadoop.util.ToolRunner;


public class ContarPalavrasDriver extends Configured implements Tool{

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		//executar o trabalho
		int cod_saida = ToolRunner.run(new ContarPalavrasDriver(), args);
		System.exit(cod_saida);
	}


	@Override
	public int run(String[] arg0) throws Exception {
		// TODO Auto-generated method stub
		//criando configuração
		Configuration conf = new Configuration();
		
		//preparando um objeto job
		Job job = new Job(conf, "Contar Palavras");
		
		//link driver .class com o job
		job.setJarByClass(ContarPalavrasDriver.class);
		
		//link mapper .class com o job
		job.setMapperClass(ContarPalavrasMapper.class);
		
		//link reducer .class com o job
		job.setReducerClass(ContarPalavrasReducer.class);
		
		//definir caminho dos arquivos de entrada
		FileInputFormat.addInputPath(job, new Path(arg0[0]));
		
		//definir caminho de saida
		FileOutputFormat.setOutputPath(job, new Path(arg0[1]));
		
		//definir tipo de saida da chave
		job.setOutputKeyClass(Text.class);
		
		//definir tipo de saida do valor
		job.setOutputValueClass(IntWritable.class);
		
		
		return job.waitForCompletion(true)? 0 : 1;
	}

}
