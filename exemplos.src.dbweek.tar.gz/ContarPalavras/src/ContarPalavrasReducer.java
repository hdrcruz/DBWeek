import java.io.IOException;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;


public class ContarPalavrasReducer extends Reducer <Text,IntWritable,Text,IntWritable>{
	
	private IntWritable resultado = new IntWritable();
	
	protected void reduce(Text palavra, Iterable<IntWritable> valores, Context context) throws IOException, InterruptedException{
		
		System.out.println("Chave = " + palavra);
		int soma = 0;
	
		//percorrer toda a lista de valores e somar
		for (IntWritable val : valores ){
			soma += val.get();
		}
		
		//resultado, do tipo IntWritable, que é o tipo de retorno para o valor da função reduce
		//recebe o valor da soma
		resultado.set(soma);
		
		//escrevemos o resultado no contexto
		context.write(palavra, resultado);
		
		
		
	}

	
}
