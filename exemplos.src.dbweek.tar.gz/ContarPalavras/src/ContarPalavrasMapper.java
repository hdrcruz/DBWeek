import java.io.IOException;
import java.util.StringTokenizer;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;


public class ContarPalavrasMapper extends Mapper<LongWritable, Text, Text, IntWritable>{
	
	private Text palavra = new Text(); //criando palavra do tipo text que irá receber cada palavra lida
	
	protected void map(LongWritable chave, Text valor, Context context ) throws IOException, InterruptedException{
		
		
		//Dividimos o conteudo de valor em strings menores
		StringTokenizer itr = new StringTokenizer(valor.toString());
		
		//percorremos todos os valores
		//uma variavel to tipo Text recebe cada palavra
		//escrevemos o par (palavra, 1) no contexto
		while(itr.hasMoreTokens()){
			palavra.set(itr.nextToken());
			context.write(palavra, new IntWritable(1));		
		}
	}
}
